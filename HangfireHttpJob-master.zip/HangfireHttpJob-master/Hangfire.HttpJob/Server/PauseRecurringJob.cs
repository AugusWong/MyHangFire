﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hangfire.HttpJob.Server
{
   public class PauseRecurringJob
    {
        public string Id { get; set; }
    }
}
